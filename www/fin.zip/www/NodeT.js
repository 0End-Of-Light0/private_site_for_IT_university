calculateAverage = (data) => {
    if (data.length === 0) {
      return 0;
    }
    var sum = 0;
    for (var i = 0; i < data.length; i++) {
      sum += data[i];
    }
    return sum / numbers.length;
  };
  
  
  process.stdin.on('data', (data) => {
       res = calculateAverage(data);
       process.stdout.write(res);
       proess.exit();
  });